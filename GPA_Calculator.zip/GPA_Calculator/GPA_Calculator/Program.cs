﻿using System;

namespace GPA_Calculator
{
    internal class Program
    {
        const int MAX_SEMESTERS = 10;
        const int MAX_SUBJECTS = 10;
        static string[] subjects = new string[MAX_SUBJECTS];
        static int[] creditHours = new int[MAX_SUBJECTS];
        static int[] marks = new int[MAX_SUBJECTS];
        static double[] GPA = new double[MAX_SEMESTERS];
        static double CGPA;
        static int numSemesters = 0;
        static int[] numSubjects = new int[MAX_SEMESTERS];

        static double CalculateGPA(int[] marks, int[] creditHours, int numSubjects)
        {
            double totalPoints = 0.0;
            int totalCredits = 0;

            for (int i = 0; i < numSubjects; ++i)
            {
                if (marks[i] >= 50)
                {
                    totalPoints += (marks[i] - 50) / 10.0 * creditHours[i];
                }
                totalCredits += creditHours[i];
            }

            if (totalCredits != 0)
            {
                return totalPoints / totalCredits;
            }
            else
            {
                return 0.0;
            }
        }

        static void AddSubjectDetail()
        {
            int num = 0;
            Console.Write("Enter number of semesters: ");
            numSemesters = int.Parse(Console.ReadLine());

            for (int semester = 0; semester < numSemesters; semester++)
            {
                Console.Write($"Enter number of subjects for semester {semester + 1}: ");
                numSubjects[semester] = int.Parse(Console.ReadLine());

                for (int i = 0; i < numSubjects[semester]; ++i)
                {
                    Console.Write($"Enter subject {i + 1} name: ");
                    subjects[num] = Console.ReadLine();

                    Console.Write($"Enter credit hours for subject {subjects[num]}: ");
                    creditHours[num] = int.Parse(Console.ReadLine());

                    Console.Write($"Enter marks for subject {subjects[num]}: ");
                    marks[num] = int.Parse(Console.ReadLine());
                    num++;
                }
                GPA[semester] = CalculateGPA(marks, creditHours, numSubjects[semester]);
                CGPA += GPA[semester];
            }
        }

        static void DisplayGPA()
        {
            for (int i = 0; i < numSemesters; i++)
            {
                Console.WriteLine($"Your GPA for Semester {i + 1}: {GPA[i]}");
            }
        }

        static void DisplaySubjectList()
        {
            int num = 0;
            for (int i = 0; i < numSemesters; i++)
            {
                Console.WriteLine($"Subjects List For Semester {i + 1}: ");
                for (int j = 0; j < numSubjects[i]; ++j)
                {
                    Console.WriteLine($"{j + 1}. {subjects[num]} \t Credit Hours: {creditHours[num]} \t Marks: {marks[num]}");
                    num++;
                }
            }
        }

       

        static void Instructions()
        {
            Console.WriteLine();
            Console.WriteLine("-----------------------------------------");
            Console.WriteLine("Instructions For Calculating GPA and CGPA");
            Console.WriteLine("-----------------------------------------");
            Console.WriteLine();
            Console.WriteLine("Read instructions carefully before using calculator:");
            Console.WriteLine("*Grade Point Average is calculated by the following formula: ");
            Console.WriteLine("*GPA = Sum of((marks - passing mark) / 10 * credit hours) / Sum of credit hours");
            Console.WriteLine("*Passing marks are 50, and the maximum marks are 100.");
            Console.WriteLine("*Cumulative Grade Point Average(CGPA) is calculated by the following formula: ");
            Console.WriteLine("*CGPA = Sum of(GPA of each semester) / Number of semesters");
            Console.WriteLine("*CGPA is basically the average of all the semester's GPA.");
            Console.WriteLine("*Use the calculator options to input subject names, calculate GPA, CGPA, or view subject details.");
        }

        static void Header()
        {
            Console.WriteLine("##################################################################################");
            Console.WriteLine("##                                                                              ##");
            Console.WriteLine("#---------------------->>>>>>>GPA and CGPA Calculator<<<<<<<---------------------#");
            Console.WriteLine("##                                                                              ##");
            Console.WriteLine("##################################################################################");
        }

        static void ClearScreen()
        {
            Console.WriteLine("Press any key to continue....");
            Console.ReadKey();
        }

        static int Menu()
        {
            int op;
            Console.WriteLine("\t1--->>>Instructions and Formula for Calculating GPA and CGPA");
            Console.WriteLine("\t2--->>>Add Your Subjects Details");
            Console.WriteLine("\t3--->>>Calculate GPA");
            Console.WriteLine("\t4--->>>Calculate CGPA");
            Console.WriteLine("\t5--->>>View Subject List(Name, Credit Hours, and Marks)");
            Console.WriteLine("\t6--->>>Exit Application");
            Console.Write("\tChoose an option from above given options: ");
            op =  int.Parse(Console.ReadLine());
            return op;
        }

        static void CalculateCGPA()
        {
            double cgpa = CGPA / numSemesters;
            Console.WriteLine($"Your current CGPA is: {cgpa}");
        }

        static void ExitLogo()
        {
            Console.WriteLine("\t%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");
            Console.WriteLine("\t%                                      %");
            Console.WriteLine("\t%Thanks for Using Calculator. Good Bye!%");
            Console.WriteLine("\t%                                      %");
            Console.WriteLine("\t%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%");
        }

        static void Main(string[] args)
        {
            Console.BackgroundColor= ConsoleColor.Black;
            Console.ForegroundColor= ConsoleColor.Cyan;

            while (true)
            {
                Console.Clear();
                Header();
                int option = Menu();
                if (option == 1)
                {
                    Console.Clear();
                    Header();
                    Instructions();
                    ClearScreen();
                }
                else if (option == 2)
                {
                    Console.Clear();
                    Header();
                    AddSubjectDetail();
                    ClearScreen();
                }
                else if (option == 3)
                {
                    Console.Clear();
                    Header();
                    DisplayGPA();
                    ClearScreen();
                }
                else if (option == 4)
                {
                    Console.Clear();
                    Header();
                    CalculateCGPA();
                    ClearScreen();
                }
                else if (option == 5)
                {
                    Console.Clear();
                    Header();
                    DisplaySubjectList();
                    ClearScreen();
                }
                else if (option == 6)
                {
                    Console.Clear();
                    ExitLogo();
                    Console.Read();
                    break;
                }
            }
        }
    }
}
